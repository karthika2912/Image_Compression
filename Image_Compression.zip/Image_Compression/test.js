// Requiring module
const express = require('express');

// Creating express object
const app = express();

// Defining port number
const PORT = 3000;				


// Server setup
app.get("/",(req,res)=>{
    res.render("index",{res:"images/image.jpeg"})//index.hbs
    console.log("in index");
});
app.listen(PORT, () => {
console.log(`Running server on PORT ${PORT}...`);
})
