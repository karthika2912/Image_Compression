const {PythonShell} =require('python-shell');
const express=require("express")
const port=process.env.PORT || 3000
const app=express()
const path=require("path");
const multer=require("multer");
app.set("view engine","hbs")

app.use(express.static('views'));
app.use('views', express.static('views'));


app.use(express.json())
app.use(express.urlencoded({extended:false}));
const maxSize = 1 * 1000 * 1000;
var storage = multer.diskStorage({
    destination: function (req, file, cb) {

        cb(null, "images");
    },
    filename: function (req, file, cb) {
      cb(null, "Karthika"+".jpg")
    }
  })

var upload = multer({ 
    storage: storage,
    limits: { fileSize: maxSize },
    fileFilter: function (req, file, cb){
    
        // Set the filetypes, it is optional
        var filetypes = /jpeg|jpg|png/;
        var mimetype = filetypes.test(file.mimetype);
  
        var extname = filetypes.test(path.extname(
                    file.originalname).toLowerCase());
        
        if (mimetype && extname) {
            return cb(null, true);
        }
      
        cb("Error: File upload only supports the "
                + "following filetypes - " + filetypes);
      } 
  
// mypic is the name of file attribute
}).single("mypic");

app.listen(port,()=>{
    console.log(`server is running at port ${port}`);
})
console.log(__dirname);


app.get("/",(req,res)=>{
    res.render("index",{res:"images/image.jpeg"})//index.hbs
    console.log("in index");
});
app.post("/check",(req,res)=>{
   upload(req,res,function(err) {
  
    console.log("in pso");
    
    var h=(req.body.mypic);
    
    
    let options = {
		mode: 'text',
		pythonOptions: ['-u'],
        args: ["images/karthika.jpg",]
        
	};
    PythonShell.run('script.py', options, function (err, result){
		if (err) throw err;
		
		console.log('result: ', result.toString());
         k=result.toString();
         console.log(__dirname);
        console.log()
         res.render("index",{red:k});
        
	});
    
    
})
});