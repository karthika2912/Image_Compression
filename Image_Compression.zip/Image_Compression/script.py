from PIL import Image
import glob
import os
import sys
image = Image.open(sys.argv[1])

image2=os.stat(sys.argv[1])
a=image2.st_size
image = image.convert('RGB')
image.save('views/final_image.jpg', 'webp')

image1= os.stat('views/final_image.jpg')

b=image1.st_size
per=(b/a)*100
result=str(per)

print(result)